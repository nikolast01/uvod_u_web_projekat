Funkcije na stranicama:
 - Na svim stranicama u gornjem desnom uglu postoji ikonica meseca koja menja temu stranice.

 - Na stranici "Mobilna" dugmići "Cube Silver" i "Cube Gold" menjaju tarife, 
   dok "Postpejd" i "Pripejd" menjaju izgled tabele.

 - Na stranici "Fiksna" naslovi "Dolazni pozivi" i "Odlazni pozivi" menjaju pogodnosti
   dostupne za određenu vrstu poziva.

 - Na stranici "Internet" dugmići "+Više" otvaraju pop-up prozor, a takođe je tu i baner sa 
   carusel funkcijom

 - Na stranici "Uređaji" prelaskom (hoverovanjem) preko uređaja prikazuje se mali 
   "meni" sa specifikacijama

 - Na stranici "O nama" u zavisnosti od unete ocene za sajt, prilikom klika na 
   dugme "Pošalji" izlazi odgovarajuća poruka.


Responsive je urađen za Mobile S - 320px i Tablet - 768px

CSS:
Linija 7 - Header
Linija 115 - Content - "POČETNA"
Linija 200 - Footer
Linija 265 - "O NAMA"
Linija 307 - "MOBILNA"
Linija 473 - "FIKSNA"
Linija 536 - "NET"
    - "NET" pop-up prozor: linija 586
Linija 627 - "UREĐAJI"
Responsive: linija 686