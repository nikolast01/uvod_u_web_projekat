let btnPosalji = document.getElementById("posalji");
let divIspisi = document.getElementById("ispis");
let inputIme = document.getElementById("ime");
let ta = document.getElementById("ta");
let radiosOcena = document.querySelectorAll(".ocena");

btnPosalji.addEventListener("click", (e) => {
  e.preventDefault();
  let valueIme = inputIme.value;

  let valueOcena = "5";
  for (let i = 0; i < radiosOcena.length; i++) {
    if (radiosOcena[i].checked == true) {
      valueOcena = radiosOcena[i].value;
    }
  }
  if (valueOcena == "1" || valueOcena == "2" || valueOcena == "3") {
    divIspisi.innerHTML = valueIme + ", recite nam šta treba da poboljšamo.";
    ta.style.display = "block";
  }
  if (valueOcena == "4" || valueOcena == "5") {
    divIspisi.innerHTML = valueIme + ", hvala Vam na dobroj oceni!";
    ta.style.display = "none";
  }
});
