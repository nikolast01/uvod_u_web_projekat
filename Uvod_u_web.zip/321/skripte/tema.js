// Promena teme za hedere stranica
var imee = document.getElementById("imee");
var drop = document.getElementById("drop");
var naav = document.getElementById("naav");
var tema = document.getElementById("tema");

function temaHeder() {
  imee.classList.toggle("noc5");
  drop.classList.toggle("noc5");
  naav.classList.toggle("noc5");

  tema.children[0].classList.toggle("prikaz");
  tema.children[1].classList.toggle("prikaz");
}

////////////////////////////////////////////////////
// Promena teme za divove na glavnoj stranici
var mobilna = document.getElementById("mob");
var fiksna = document.getElementById("fik");
var net = document.getElementById("net");
var ur = document.getElementById("ur");

var d1 = document.getElementById("d1");
var d2 = document.getElementById("d2");
var d3 = document.getElementById("d3");
var d4 = document.getElementById("d4");

function promeniTemu() {
  mobilna.classList.toggle("noc");
  fiksna.classList.toggle("noc2");
  net.classList.toggle("noc3");
  ur.classList.toggle("noc4");

  d1.classList.toggle("oboji");
  d2.classList.toggle("oboji");
  d3.classList.toggle("oboji");
  d4.classList.toggle("oboji");
}
////////////////////////////////////////////////////
// Promena teme za stranicu "o nama"
var tekst = document.getElementById("ja");
var pos = document.getElementById("posalji");
var sub = document.getElementById("resetuj");
function temaONama() {
  tekst.classList.toggle("noc3");
  pos.classList.toggle("oboji");
  sub.classList.toggle("oboji");
}
////////////////////////////////////////////////////
// Promena teme za stranicu "mobilna"
var post = document.getElementById("post");
var nas = document.getElementById("n");
var pri = document.getElementById("pri");
var rom = document.getElementById("roming");

function temaMob() {
  post.classList.toggle("noc2");
  nas.classList.toggle("po");
  pri.classList.toggle("noc4");
  rom.classList.toggle("noc");
}
////////////////////////////////////////////////////
// Promena teme za stranicu "net"
var cont = document.getElementById("netCont");
function temaNet() {
  cont.classList.toggle("noc4");
}
////////////////////////////////////////////////////
// Promena teme za stranicu "uredjaji"
var tel = document.getElementById("telefoni");
function temaUr() {
  tel.classList.toggle("noc3");
}
////////////////////////////////////////////////////
// Promena teme za stranicu "fiksna"
var fikk = document.getElementById("fikk");
var om = document.getElementById("omotacFik");
function temaFik() {
  fikk.classList.toggle("noc4");
  om.classList.toggle("noc4");
}
// Funkcija za dolazne i odlazne pozive za stranicu fiksna, nije htela da radi u scripts...
var dol = document.getElementById("dol");
var odl = document.getElementById("odl");
var dolazni = document.getElementById("dolaznii");
var odlazni = document.getElementById("odlaznii");
var omo = document.getElementById("omotacFik");

dol.onclick = () => {
  odlazni.style.display = "none";
  dolazni.style.display = "block";
  omo.style.height = "730px";

  odl.classList.add("poziv");
  dol.classList.remove("poziv");
};
odl.onclick = () => {
  odlazni.style.display = "block";
  dolazni.style.display = "none";
  omo.style.height = "500px";
  dol.classList.add("poziv");
  odl.classList.remove("poziv");
};