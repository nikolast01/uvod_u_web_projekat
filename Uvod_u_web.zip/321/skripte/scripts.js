// Skrol funkcija
var skrol = document.getElementById("skrol");

window.onscroll = function () {
  skrolFja();
};

function skrolFja() {
  if (
    document.body.scrollTop > 250 ||
    document.documentElement.scrollTop > 250
  ) {
    skrol.style.display = "block";
  } else {
    skrol.style.display = "none";
  }
}

function idiNaVrh() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
////////////////////////////////////////////////////

var silBtn = document.getElementById("sil");
var goldBtn = document.getElementById("gol");
var silverDiv = document.getElementById("silver");
var goldDiv = document.getElementById("gold");

silBtn.onclick = () => {
  goldDiv.style.display = "none";
  silverDiv.style.display = "block";

  silBtn.style.color = "whitesmoke";
  silBtn.style.backgroundColor = "#239cca";
  goldBtn.style.color = "#239cca";
  goldBtn.style.backgroundColor = "whitesmoke";
};
goldBtn.onclick = () => {
  goldDiv.style.display = "block";
  silverDiv.style.display = "none";

  goldBtn.style.color = "whitesmoke";
  goldBtn.style.backgroundColor = "#239cca";
  silBtn.style.color = "#239cca";
  silBtn.style.backgroundColor = "whitesmoke";
};

function klik() {
  alert("Uspešno naručeno!");
}

////////////////////////////////////////////////////

var poBtn = document.getElementById("poBtn");
var priBtn = document.getElementById("priBtn");
var tab1 = document.getElementById("tabela1");
var tab2 = document.getElementById("tabela2");

poBtn.onclick = () => {
  tab2.style.display = "none";
  tab1.style.display = "block";

  poBtn.style.color = "whitesmoke";
  poBtn.style.backgroundColor = "#239cca";
  priBtn.style.color = "#239cca";
  priBtn.style.backgroundColor = "whitesmoke";
};
priBtn.onclick = () => {
  tab2.style.display = "block";
  tab1.style.display = "none";

  priBtn.style.color = "whitesmoke";
  priBtn.style.backgroundColor = "#239cca";
  poBtn.style.color = "#239cca";
  poBtn.style.backgroundColor = "whitesmoke";
}; 

