var pop = document.getElementById("popUp");
var pop2 = document.getElementById("popUp2");
var pop3 = document.getElementById("popUp3");
var pop4 = document.getElementById("popUp4");

var v1 = document.getElementById("v1");
var v2 = document.getElementById("v2");
var v3 = document.getElementById("v3");
var v4 = document.getElementById("v4");

var closeBtn = document.getElementById("X");

v1.onclick = function() {
  pop.style.display = "block";
}
v2.onclick = function() {
  pop.style.display = "block";
}
v3.onclick = function() {
  pop.style.display = "block";
}
v4.onclick = function() {
  pop.style.display = "block";
}

closeBtn.onclick = function() {
  pop.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == pop) {
    pop.style.display = "none";
  }
}
// funkcija za banere
var trenutnaSlika = 0;
var slike = document.getElementById("slike");

setInterval(carusel, 5000);

function carusel() {
  slike.children[trenutnaSlika].classList.remove("activeImg");

  trenutnaSlika = (trenutnaSlika +1) % 5;

  slike.children[trenutnaSlika].classList.add("activeImg");
}